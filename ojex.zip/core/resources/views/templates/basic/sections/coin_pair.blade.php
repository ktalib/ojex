<div class = "py-120 table-section ">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <x-flexible-view :view="$activeTemplate.'sections.coin_pair_list'" :meta="['from_section' => true ]" />
            </div>
        </div>
    </div>
</div>



