<section class="banner-two-section bg-img" data-background-image="{{ getImage( $activeTemplateTrue . 'images/shapes/banner-bg.png') }}">
    <div class="banner-two-shap-bg">
        <div class="shape-one-bg"></div>
        <div class="shape-two-bg"></div>
        <div class="shape-three-bg"></div>
        <div class="shape-four-bg"></div>
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <div class="banner-content">
                    <h1 class="about-content__title mb-0">{{ __($pageTitle) }}</h1>
                </div>
            </div>
        </div>
    </div>
</section>
